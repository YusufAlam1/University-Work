module Main where


-- | Main Program
main :: IO ()
main = putStrLn "1JC3-Assign4 compiled successfully"
